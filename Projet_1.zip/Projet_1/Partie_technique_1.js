//Mettre a jour le prix total des achats en usant de cette option
function UpdateAll() {
    var qty1 = parseInt(document.getElementById('qty1').textContent)
    var qty2 = parseInt(document.getElementById('qty2').textContent)
    var qty3 = parseInt(document.getElementById('qty3').textContent)
    let total = qty1 * 100 + qty2 * 20 + qty3 * 50;
    document.getElementById('total').textContent = ' ' + total + ' $'
}
//Augmente la quantité d'un article dans une section, toute en mettant à jour le prix total
function increaseQty(id) {
    const qtyElement = document.getElementById(id);
    let current = parseInt(qtyElement.textContent);
    qtyElement.textContent = current + 1;
    UpdateAll();
}
//Diminuer la quantité d'un article dans une section, toute en mettant à jour le prix total
function decreaseQty(id) {
    const qtyElement = document.getElementById(id);
    let current = parseInt(qtyElement.textContent);
    if (current > 0) {
    qtyElement.textContent = current - 1;
    }
    UpdateAll();
}
//Réinitialiser la quantité d'un article dans une section, toute en mettant à jour le prix total
function EraseAll(id) {
    const qtyElement = document.getElementById(id);
    qtyElement.textContent = 0;
    UpdateAll();
}

//Programme pour le bouton like :

var button_1 = document.getElementById('like_button_1');
var button_2 = document.getElementById('like_button_2');
var button_3 = document.getElementById('like_button_3');
button_1.addEventListener('click',Like_1);
button_2.addEventListener('click',Like_2);
button_3.addEventListener('click',Like_3);

//Créer une fonction pour "like" : 
function Like_1() {
    document.getElementById('like_1').style.color = 'red'
    this.removeEventListener('click',Like_1);
    this.addEventListener('click', Unlike_1)}
function Unlike_1() { //Créer une fonction pour "unlike" : 
    document.getElementById('like_1').style.color = 'black'
    this.removeEventListener('click',Unlike_1);
    this.addEventListener('click',Like_1)
}

//Répétition pour les autres articles :
function Like_2() {
    document.getElementById('like_2').style.color = 'red'
    this.removeEventListener('click',Like_2);
    this.addEventListener('click', Unlike_2)}
function Unlike_2() {
    document.getElementById('like_2').style.color = 'black'
    this.removeEventListener('click',Unlike_2);
    this.addEventListener('click',Like_2)
}


function Like_3() {
    document.getElementById('like_3').style.color = 'red'
    this.removeEventListener('click',Like_3);
    this.addEventListener('click', Unlike_3)}
function Unlike_3() {
    document.getElementById('like_3').style.color = 'black'
    this.removeEventListener('click',Unlike_3);
    this.addEventListener('click',Like_3)
}
